{{
  config(
    materialized='datastage'
    
    
    
    , table_action='append'
    , write_mode='insert'
    
    
    
    
    
    
    
    
    
    , force_commit='false'
    
    , use_adapter_drop_statement='false'
  )
}}


SELECT CUSTOMER_ID, EMAIL, NAME, SIGNUP_DATE
FROM ATTTEST.CUSTOMERS

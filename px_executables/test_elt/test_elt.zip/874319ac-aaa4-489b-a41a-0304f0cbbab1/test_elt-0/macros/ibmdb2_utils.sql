{% macro ibmdb2__get_quotes(col) %}
  {{ return ('"'~col~'"') }}
{% endmacro %}

{% macro ibmdb2__with_nodata() %}
  {{ return ('WITH NO DATA') }}
{% endmacro %}

-- Using "getprefix", getpostfix macros to return
-- BEGIN, END caused all SQLs to be submitted in
-- BEGIN/END block, which is failing when DDL
-- statements are executed. Hence, adding
-- separate macros, that are used ONLY for
-- dual-write-mode statements.

{%- macro ibmdb2__get_begin_stmt() -%}
  {{ return ("BEGIN") }}
{%- endmacro -%}

{%- macro ibmdb2__get_end_stmt() -%}
  {{ return ("END;") }}
{%- endmacro -%}

-- To return empty string for ending semi-colon for DB2
-- because it is causing ";;" in delete_insert-sql, which
-- failing for db2.
{%- macro ibmdb2__get_ending_semicolon() -%}
  {{ return ("") }}
{%- endmacro -%}

-- To escape single-quote (i.e., to replace single-quote 
-- in the sql-stmt with two single-quotes) & to remove
-- the semi-colon from sql-stmt.
{%- macro escape_quote( sql ) -%}
  {%- set modified_sql = ( sql|replace(";","")|replace("'","''") ) -%}
  {{ return (modified_sql) }}
{%- endmacro -%}

-- To execute the SQL-statements with 
-- EXECUTE IMMEDIATE (i.e., dynamic-sql) 
-- prefix, when the table-action-sql is
-- not empty.
{%- macro ibmdb2__get_exec_immediate_sql(table_action_sql, write_mode_sql) -%}
  {% do return (get_begin_stmt() ~ "\nEXECUTE IMMEDIATE '" ~ escape_quote(table_action_sql) ~ "';" ~ "\nEXECUTE IMMEDIATE '" ~ escape_quote(write_mode_sql) ~ "';\n" ~ get_end_stmt()) %}
{%- endmacro -%}

-- To generate EXECUTE IMMEDIATE (i.e., dynamic-sql) statements
-- when both table-action-sql & write-mode-sql are not empty.
{% macro ibmdb2__get_build_sql(custom_table_action_dict, table_action, write_mode, table_action_sql, write_mode_sql, target_relation ) %}
  {{ log("**** write_mode=" ~ write_mode) }}
  {{ log("**** custom_table_action_dict=" ~ custom_table_action_dict['tbl_action']) }}
  {% if custom_table_action_dict['tbl_action'] == False  %}
    {% if write_mode in ['insert','merge','update_statement_table_action'] or ("delete_insert" == write_mode and table_action in ['append','replace']) or (write_mode in ['update'] and table_action in ['replace']) or (write_mode in ['delete','insert_update'] and table_action in ['create','replace']) or (write_mode in ['delete_insert'] and table_action in ['create']) %}
      {%- if table_action_sql|trim -%}
        {%- if write_mode != 'merge'  -%}
          {%- if write_mode_sql|trim -%}
            {{ get_exec_immediate_sql(table_action_sql, write_mode_sql) }}
          {%- else -%}
            {{ table_action_sql }}
          {%- endif -%}
        {%- else -%}
          {{ table_action_sql }}
          {{ write_mode_sql }}
        {%- endif -%}
      {%- else -%}
        {{ write_mode_sql }}
      {%- endif -%}
    {% else %}
      {{ write_mode_sql }}
    {% endif %}
  {% else %}
    {{ write_mode_sql }}
  {% endif %}
{% endmacro %}

{%- macro ibmdb2__truncate() -%}
  {{ return (" delete from ") }}
{%- endmacro -%}

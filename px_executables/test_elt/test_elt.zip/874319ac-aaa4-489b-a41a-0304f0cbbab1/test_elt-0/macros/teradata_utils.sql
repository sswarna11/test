{%- macro teradata__if_exists() -%}
  {{ return ("") }}
{%- endmacro -%}

{%- macro teradata__with_cascade() -%}
  {{ return ("") }}
{%- endmacro -%}

{%- macro teradata__get_predicate_true() -%}
  {{ return ("1=1") }}
{%- endmacro -%}
 
{%- macro teradata__get_predicate_false() -%}
  {{ return ("1=0") }}
{%- endmacro -%}

{%- macro teradata__with_nodata() -%}
  {{ return ("WITH NO DATA") }}
{%- endmacro -%}

{%- macro teradata__truncate() -%}
  {{ return (" delete ") }}
{%- endmacro -%}

{%- macro teradata__gettruncatepostfix() -%}
  {{ return (" all ") }}
{%- endmacro -%}

{% macro teradata__get_update_sql(use_merge, target, source, unique_key, dest_columns, predicates=none) -%}
  {%- set predicates = get_predicates(unique_key, source, target, get_predicate_false(), predicates) -%}
  {%- set update_columns =  dest_colums | map(attribute="quoted") | list -%}

  {{ sql_header if sql_header is not none }}
  {% set assign=[]%}

  {%for col in dest_columns %}
    {%- do assign.append(col ~'=DBT_INTERNAL_SOURCE.'~ col)-%}
  {%- endfor %}

  {%- set assign_res=assign | join(', ') -%}
  {%- set dest_columns_csv = get_quoted_csv(dest_columns) -%}

  {% if use_merge %}
  merge into {{ target }} as DBT_INTERNAL_DEST using
  (select {{ dest_columns_csv }} from {{ source }}) DBT_INTERNAL_SOURCE
  on {{ predicates | join(' and ') }}
  when matched then update set {{ assign_res }}
  {% else %}
  update DBT_INTERNAL_DEST from {{ target }} as DBT_INTERNAL_DEST, {{ source }} as  DBT_INTERNAL_SOURCE
  set {{ assign_res }}
  where {{ predicates | join(' and ') }}
  {% endif %}

{% endmacro %}

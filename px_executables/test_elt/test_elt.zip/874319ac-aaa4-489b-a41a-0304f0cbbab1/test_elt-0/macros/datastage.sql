{% macro create_empty_table_as(temporary, relation, sql) -%}
  {%- set unlogged = config.get('unlogged', default=false) -%}
  {%- set sql_header = config.get('sql_header', none) -%}

  {{ sql_header if sql_header is not none }}

  create {% if temporary -%}
    temporary
  {%- elif unlogged -%}
    unlogged
  {%- endif %} table {{ relation }}
  as (
    select * from ({{ sql }}) t where {{ get_predicate_false() }} 
  ) {{ with_nodata() }}
{%- endmacro %}

{%- macro getprefix() -%}
  {{ return(
        adapter.dispatch('getprefix')() ) }}
{%- endmacro -%}

{%- macro getpostfix() -%}
  {{ return(
        adapter.dispatch('getpostfix')() ) }}
{%- endmacro -%}

{%- macro getstatementprefix() -%}
  {{ return(
        adapter.dispatch('getstatementprefix')() ) }}
{%- endmacro -%}

{%- macro getstatementpostfix() -%}
  {{ return(
        adapter.dispatch('getstatementpostfix')() ) }}
{%- endmacro -%}

{%- macro default__getprefix() -%}
  {{ return ("") }}
{%- endmacro -%}

{%- macro default__getpostfix() -%}
  {{ return ("") }}
{%- endmacro -%}

{%- macro default__getstatementprefix() -%}
  {{ return ("") }}
{%- endmacro -%}

{%- macro default__getstatementpostfix() -%}
  {{ return (";") }}
{%- endmacro -%}

-- The macro: "get_begin_stmt" is implemented/needed 
-- only for DB2 & returns empty string by default.
{%- macro get_begin_stmt() -%}
  {{ return(
        adapter.dispatch('get_begin_stmt')() ) }}
{%- endmacro -%}

{%- macro default__get_begin_stmt() -%}
  {{ return ("") }}
{%- endmacro -%}

-- The macro: "get_end_stmt" is implemented/needed 
-- only for DB2 & returns empty string by default.
{%- macro get_end_stmt() -%}
  {{ return(
        adapter.dispatch('get_end_stmt')() ) }}
{%- endmacro -%}

{%- macro default__get_end_stmt() -%}
  {{ return ("") }}
{%- endmacro -%}

{%- macro dropexception() -%}
  {{ return(
        adapter.dispatch('dropexception')() ) }}
{%- endmacro -%}

{%- macro default__dropexception() -%}
  {{ return ("") }}
{%- endmacro -%}

{%- macro if_exists() -%}
  {{ return(
        adapter.dispatch('if_exists')() ) }}
{%- endmacro -%}
    
{%- macro default__if_exists() -%}
  {{ return (" if exists ") }}
{%- endmacro -%}

{%- macro quotehandling( sql ) -%}
  {{ return (adapter.dispatch('quotehandling')( sql )) }}
{%- endmacro -%}

{%- macro default__quotehandling( sql ) -%}
  {{ return (sql) }}
{%- endmacro -%}

{%- macro truncate() -%}
  {{ return(
        adapter.dispatch('truncate')() ) }}
{%- endmacro -%}

{%- macro default__truncate() -%}
  {{ return ( " truncate table " ) }}
{%- endmacro -%}

{%- macro gettruncatepostfix() -%}
  {{ return(
        adapter.dispatch('gettruncatepostfix')() ) }}
{%- endmacro -%}

{%- macro default__gettruncatepostfix() -%}
  {{ return ( "" ) }}
{%- endmacro -%}

{% macro validate_table_action(config) %}
  {%- set table_action = config.get('table_action') -%}
  {%- set write_mode = config.get('write_mode') -%}
  {% if write_mode in ['update','custom_statement','delete', 'update_statement', 'delete_insert', 'insert_update'] %}
    {% do return(table_action) %}
  {% endif %}
  {% if table_action not in ['append', 'create', 'replace', 'truncate'] %}
    {%- set invalid_table_action_msg -%}
      Invalid table action provided: {{ table_action}}
      Expected one of: 'append', 'create', 'replace', 'truncate'
    {%- endset -%}
    {% do exceptions.raise_compiler_error(invalid_table_action_msg) %}
  {% endif %}
  {% do return(table_action) %}
{% endmacro %}

{% macro validate_write_mode(config) %}
  {%- set write_mode = config.get('write_mode') -%}
  {%- set custom_statement_sql = config.get("custom_statement_sql") -%}
  {%- set custom_update_sql = config.get("custom_update_sql") -%}
  {% if write_mode not in ['insert', 'merge', 'update', 'custom_statement', 'update_statement', 'update_statement_table_action','delete', 'delete_insert', 'insert_update', 'update_insert'] %}
    {%- set invalid_write_mode_msg -%}
      Invalid write mode provided: {{ write_mode }}
      Expected one of: 'insert','merge', 'update', 'custom_statement', 'update_statement', 'update_statement_table_action', 'delete', 'delete_insert', 'insert_update'
    {%- endset -%}
    {% do exceptions.raise_compiler_error(invalid_write_mode_msg) %}
  {% endif %}

  {% if "custom_statement" == write_mode and custom_statement_sql is none %}
    {% do exceptions.raise_compiler_error(write_mode ~ " requires custom sql statement") %}
  {% endif %}

  {% if write_mode in ["update_statement", "update_statement_table_action"] and custom_update_sql is none %}
    {% do exceptions.raise_compiler_error(write_mode ~ " requires custom update sql statement") %}

  {% endif %}

  {% do return(write_mode) %}
{% endmacro %}

{% macro get_table_action_sql(tgt_relation_dict, table_action, write_mode, custom_create_sql, custom_drop_sql, custom_truncate_sql, dest_relation, direct_target, existing_relation, use_adapter_drop_statement) %}
  {{ log("existing relation: " ~ existing_relation )}}
  {{ log("use_adapter_drop_statement: " ~ use_adapter_drop_statement )}}
  {# -- datastage ui doesn't have table action for the write modes below #}
  {#-- creating drop or truncate #}
  {% if write_mode not in ['custom_statement'] %}
    {% if "truncate" == table_action %}
      {% if custom_truncate_sql is not none %}
        {% do return ( getstatementprefix() ~ custom_truncate_sql | replace('\\"','"') ~ getstatementpostfix() ) %}
      {% else %}
        {{ getstatementprefix() }} {{ truncate() }} {{dest_relation}} {{ gettruncatepostfix() }} {{ getstatementpostfix() }}
      {% endif %}
    {% elif "replace" == table_action %}
      {#-- if no custom sql is provided then work with a temp table and replace the target at the end #}
      {%- if custom_create_sql is not none or custom_create_sql|trim or direct_target -%}
      	{% if use_adapter_drop_statement is none %}
          {{ getstatementprefix() }} drop {{ dest_relation.type }} {{ if_exists() }} {{ dest_relation }} {{ with_cascade() }} {{ getstatementpostfix() ~ dropexception() }}
        {%- endif %}
        {%- if existing_relation is not none -%}
          {%-   if tgt_relation_dict.update({'tgt_relation': True}) %}{%- endif %}
        {%- endif %}
      {%- endif %}
    {% endif %}
    {# -- create table: non empty table gets created only if write mode = insert #}
    {% set do_create = True if existing_relation is none else False %}
    {% if custom_create_sql is none and ("truncate" == table_action  or ("append" == table_action and existing_relation is not none)) %}
      {% set do_create = False %}
    {%- elif "replace" == table_action-%}
      {% set do_create = True %}
    {% endif %}
    {{ log("**** do_create = " ~ do_create )}}
    {% if do_create %}
      {% if custom_create_sql is none %}
        {% if "insert" == write_mode and table_action not in ['create', 'append'] %}
          {% if custom_drop_sql is not none or custom_truncate_sql is not none %}
            {# -- create empty table for custom drop and truncate sql as insert happens later #}
            {{ getstatementprefix() ~ create_empty_table_as(False, dest_relation, quotehandling(sql)) ~ getstatementpostfix() }}
          {% else %}
            {{ getstatementprefix() ~ create_table_as(False, dest_relation, sql) ~ getstatementpostfix() }}
          {% endif %}
        {% else %}
          {{ getstatementprefix() ~ create_empty_table_as(False, dest_relation, quotehandling(sql)) ~ getstatementpostfix() }}
        {% endif %}
      {% else %}
        {{ getstatementprefix() ~ custom_create_sql | replace('\\"','"') ~ getstatementpostfix() }}
      {% endif %}
    {% endif %}
  {% endif %}
  
  {% if "custom_statement" == write_mode %}
    {# -- create empty table for custom sql with create replace or truncate #}
    {% if table_action in ['create', 'replace', 'truncate'] %}
      {{ getstatementprefix() ~ create_empty_table_as(False, dest_relation, quotehandling(sql)) ~ getstatementpostfix() }}
    {% else %}
      {{ getstatementprefix() ~ create_table_as(False, dest_relation, sql) ~ getstatementpostfix() }}
    {% endif %}
  {% endif %}
  
{% endmacro %}

{% macro get_insert_into_sql(target, source, dest_columns_csv) %}
 insert into {{ target }} ({{ dest_columns_csv }})
    select {{ dest_columns_csv }}
    from  {{ source }}
{% endmacro %}

{% macro get_insert_into_not_exists_sql(target, source, dest_columns_csv, unique_key, predicates=none) -%}
  {%- set predicates = get_predicates(unique_key, source, target, get_predicate_true(), predicates) -%}
  insert into {{ target }} ({{ dest_columns_csv }})
    select {{ dest_columns_csv }}
    from  {{ source }} {{ get_table_alias_source() }} where not exists (select 1 from {{ target }} {{ get_table_alias_dest() }} where {{ predicates | join(' and ') }})
{% endmacro %}

{%- macro get_predicate_true() -%}
  {{ return(
        adapter.dispatch('get_predicate_true')() ) }}
{%- endmacro -%}
  
{%- macro default__get_predicate_true() -%}
  {{ return ("TRUE") }}
{%- endmacro -%}

{%- macro get_predicate_false() -%}
  {{ return(
        adapter.dispatch('get_predicate_false')() ) }}
{%- endmacro -%}
  
{%- macro default__get_predicate_false() -%}
  {{ return ("FALSE") }}
{%- endmacro -%}

{%- macro get_predicate_source(source) -%}
  {{ return(
        adapter.dispatch('get_predicate_source')(source) ) }}
{%- endmacro -%}
  
{%- macro default__get_predicate_source(source) -%}
  {{ return ("DBT_INTERNAL_SOURCE") }}
{%- endmacro -%}

{%- macro get_predicate_dest(target) -%}
  {{ return(
        adapter.dispatch('get_predicate_dest')(target) ) }}
{%- endmacro -%}
  
{%- macro default__get_predicate_dest(target) -%}
  {{ return ("DBT_INTERNAL_DEST") }}
{%- endmacro -%}

{%- macro get_table_alias_source() -%}
  {{ return(
        adapter.dispatch('get_table_alias_source')() ) }}
{%- endmacro -%}
  
{%- macro default__get_table_alias_source() -%}
  {{ return ("DBT_INTERNAL_SOURCE") }}
{%- endmacro -%}

{%- macro get_table_alias_dest() -%}
  {{ return(
        adapter.dispatch('get_table_alias_dest')() ) }}
{%- endmacro -%}
  
{%- macro default__get_table_alias_dest() -%}
  {{ return ("as DBT_INTERNAL_DEST") }}
{%- endmacro -%}

()
{%- macro get_ending_semicolon() -%}
  {{ return(
        adapter.dispatch('get_ending_semicolon')() ) }}
{%- endmacro -%}
  
{%- macro default__get_ending_semicolon() -%}
  {{ return (";") }}
{%- endmacro -%}

{% macro get_predicates(unique_key, source, target, default_pred, predicates=none)-%}
  {%- set predicates = [] if predicates is none else [] + predicates -%}
  {% if unique_key %}
        {% if unique_key is sequence and unique_key is not mapping and unique_key is not string %}
            {% for key in unique_key %}
                {% set this_key_match %}
                    {{ get_predicate_source(source) }}.{{ get_quotes(key) }} = {{ get_predicate_dest(target) }}.{{ get_quotes(key) }}
                {% endset %}
                {% do predicates.append(this_key_match) %}
            {% endfor %}
        {% else %}
            {% set unique_key_match %}
                {{ get_predicate_source(source) }}.{{ get_quotes(unique_key) }} = {{ get_predicate_dest(target) }}.{{ get_quotes(unique_key) }}
            {% endset %}
            {% do predicates.append(unique_key_match) %}
        {% endif %}
    {% else %}
        {% do predicates.append(default_pred) %}
    {% endif %}
    {% do return(predicates)%}
{% endmacro %}

{% macro get_delete_sql(use_merge, target, source, unique_key, dest_columns, predicates=none) -%}
{%- set predicates = get_predicates(unique_key, source, target, get_predicate_false(), predicates) -%}
{%- set dest_columns_csv = get_quoted_csv(dest_columns) -%}
{% if use_merge %}
merge into {{ target }} as DBT_INTERNAL_DEST using
  (select {{ dest_columns_csv }} from {{ source }}) DBT_INTERNAL_SOURCE
  on {{ predicates | join(' and ') }}
  when matched then delete
{% else %}
delete from {{ target }} {{ get_table_alias_dest() }}
where exists (select 1 from {{ source }} {{ get_table_alias_source() }} where {{ predicates | join(' and ') }} )
{% endif %}
{% endmacro %}

{%- macro get_delete_insert_sql(use_merge, target, source, unique_key, dest_columns, predicates=none) -%}
  {{ return(
        adapter.dispatch('get_delete_insert_sql')(use_merge, target, source, unique_key, dest_columns, predicates=none) ) }}
{%- endmacro -%}

{% macro default__get_delete_insert_sql(use_merge, target, source, unique_key, dest_columns, predicates=none) -%}
{%- set dest_columns_csv = get_quoted_csv(dest_columns) -%}
{% if use_merge %}
  {%- set predicates = get_predicates(unique_key, source, target, get_predicate_false(), predicates) -%}
  {% set source_cols=[]%}
  {%for col in dest_columns %}
    {%- do source_cols.append('DBT_INTERNAL_SOURCE.'~ col) -%}
  {%- endfor %}
merge into {{ target }} as DBT_INTERNAL_DEST using
  (select {{ dest_columns_csv }} from {{ source }}) DBT_INTERNAL_SOURCE
  on {{ predicates | join(' and ') }}
  when matched then delete
  when not matched then
  insert ({{ dest_columns_csv }}) values ({{ source_cols | join(', ') }})
{% else %}
  {% do return (get_begin_stmt() ~ getstatementprefix() ~ get_delete_sql(use_merge, target, source, unique_key, dest_columns) ~ get_ending_semicolon() ~ getstatementpostfix() ~ getstatementprefix() ~ get_insert_into_not_exists_sql(target, source, dest_columns_csv, unique_key) ~ getstatementpostfix() ~ get_end_stmt()) %}
{% endif %}
{% endmacro %}

{% macro get_insert_update_sql(use_merge, target, source, unique_key, dest_columns, predicates=none) -%}
{%- set dest_columns_csv = get_quoted_csv(dest_columns) -%}
{% if use_merge %}
  {%- set predicates = get_predicates(unique_key, source, target, get_predicate_false(), predicates) -%}
  {% set source_cols=[]%}
  {%for col in dest_columns %}
    {%- do source_cols.append('DBT_INTERNAL_SOURCE.'~ col) -%}
  {%- endfor %}
  {% set assign=[]%}
  {%for col in dest_columns %}
    {%- do assign.append(col ~'=DBT_INTERNAL_SOURCE.'~ col)-%}
  {%- endfor %}
  {%- set assign_res=assign | join(', ') -%}
merge into {{ target }} as DBT_INTERNAL_DEST using
  (select {{ dest_columns_csv }} from {{ source }}) DBT_INTERNAL_SOURCE
  on {{ predicates | join(' and ') }}
  when not matched then
  insert ({{ dest_columns_csv }}) values ({{ source_cols | join(', ') }})
  when matched then
  update set {{ assign_res }}
{% else %}
  {% do return( get_begin_stmt() ~ getstatementprefix() ~ get_insert_into_not_exists_sql(target, source, dest_columns_csv, unique_key) ~ getstatementpostfix() ~ getstatementprefix() ~ get_update_sql(use_merge, target, source, unique_key, dest_columns, predicates=none) ~ getstatementpostfix() ~ get_end_stmt() ) %}
{% endif %}
{% endmacro %}

{# dbt will call this macro by name, providing any arguments #}
{% macro get_update_sql(use_merge, target, source, unique_key, dest_columns, predicates=none) -%}

  {# dbt will dispatch the macro call to the relevant macro #}
  {{ return(
      adapter.dispatch('get_update_sql')(use_merge, target, source, unique_key, dest_columns, predicates=none)
     ) }}
{%- endmacro %}

{% macro get_quotes(col) %}
  {{ return(
      adapter.dispatch('get_quotes')(col) ) }}
{% endmacro %}

{% macro default__get_quotes(col) %}
  {{ return  (col) }}
{% endmacro %}

{% macro with_nodata() %} 
  {{ return(
      adapter.dispatch('with_nodata')() ) }}
{% endmacro %} 

{% macro default__with_nodata() %}
  {{ return ("") }}
{% endmacro %}

{% macro with_cascade() %} 
  {{ return(
      adapter.dispatch('with_cascade')() ) }}
{% endmacro %} 

{% macro default__with_cascade() %}
  {{ return ("cascade") }}
{% endmacro %}

{% macro default__get_update_sql(use_merge, target, source, unique_key, dest_columns, predicates=none) -%}
  {%- set predicates = get_predicates(unique_key, source, target, get_predicate_false(), predicates) -%}
  {%- set update_columns =  dest_colums | map(attribute="quoted") | list -%}

  {{ sql_header if sql_header is not none }}
  {% set assign=[]%}
  {%for col in dest_columns %}
    {%- do assign.append( get_quotes(col)  ~'=DBT_INTERNAL_SOURCE.'~ get_quotes(col)) -%}
  {%- endfor %}
  {%- set assign_res=assign | join(', ') -%}
  {%- set dest_columns_csv = get_quoted_csv(dest_columns) -%}

  {% if use_merge %}
  merge into {{ target }} as DBT_INTERNAL_DEST using
  (select {{ dest_columns_csv }} from {{ source }}) DBT_INTERNAL_SOURCE
  on {{ predicates | join(' and ') }}
  when matched then update set {{ assign_res }}
  {% else %}
  update {{ target }} as DBT_INTERNAL_DEST
  set
  {{ assign_res }}
  from ( select {{ dest_columns_csv }}
    from {{ source }}) DBT_INTERNAL_SOURCE
    where {{ predicates | join(' and ') }}
  {% endif %}

{% endmacro %}

{% macro get_write_mode_sql(write_mode, use_merge, target, source, unique_key, dest_columns, custom_statement_sql, custom_update_sql, custom_insert_sql, custom_delete_sql) %}
  {%- set dest_columns_csv = get_quoted_csv(dest_columns) -%}
  {% if "insert" == write_mode %}
    {% if custom_insert_sql is not none %}
        {% do return (getstatementprefix() ~ custom_insert_sql ~ getstatementpostfix()) %}
    {% else %}
        {% do return (getstatementprefix() ~ get_insert_into_sql(target, source, dest_columns_csv) ~ getstatementpostfix()) %}
    {% endif %}
  {% elif "update" == write_mode %}
    {% if custom_update_sql is not none %}
        {% do return (getstatementprefix() ~ custom_update_sql ~ getstatementpostfix()) %}
    {% else %}
        {% do return(getstatementprefix() ~ get_update_sql(use_merge, target, source, unique_key, dest_columns) ~ getstatementpostfix()) %}
    {% endif %}
  {% elif "merge" == write_mode %}
    {%- do return( get_begin_stmt() ~ getstatementprefix() ~ get_update_sql(use_merge, target, source, unique_key, dest_columns) ~ getstatementpostfix() ~ getstatementprefix() ~ get_insert_into_not_exists_sql(target, source, dest_columns_csv, unique_key) ~ getstatementpostfix() ~ get_end_stmt() ) -%}
  {% elif "custom_statement" == write_mode %}
    {{ custom_statement_sql }};
  {% elif "update_statement" == write_mode %}
    {{ custom_update_sql }};
  {% elif "update_statement_table_action" == write_mode %}
    {{ getstatementprefix() ~ custom_update_sql  ~ getstatementpostfix() }}
  {% elif "delete" == write_mode %}
    {% if custom_delete_sql is not none %}
        {% do return (getstatementprefix() ~ custom_delete_sql ~ getstatementpostfix()) %}
    {% else %}
        {% do return (getstatementprefix() ~ get_delete_sql(use_merge, target, source, unique_key, dest_columns) ~ get_ending_semicolon() ~ getstatementpostfix()) %}
    {% endif %}
  {% elif "delete_insert" == write_mode %}
    {% if custom_delete_sql is none and custom_insert_sql is none %}
      {% do return (get_delete_insert_sql(use_merge, target, source, unique_key, dest_columns)) %}
    {% else %}
      {% if custom_delete_sql is none or custom_insert_sql is none %}
        {% do exceptions.raise_compiler_error("custom delete or insert  statement is missing for write mode " ~ write_mode) %}
      {% endif %}
      {% do return ((getstatementprefix() ~ custom_delete_sql ~ getstatementpostfix()) ~ (getstatementprefix() ~ custom_insert_sql ~ getstatementpostfix())) %}
    {% endif %}
  {% elif "insert_update" == write_mode %}
    {% if custom_insert_sql is none and custom_update_sql is none %}
      {% do return (get_insert_update_sql(use_merge, target, source, unique_key, dest_columns)) %}
    {% else %}
      {% if custom_insert_sql is none or custom_update_sql is none %}
        {% do exceptions.raise_compiler_error("custom insert or update statement is missing for write mode " ~ write_mode) %}
      {% endif %}
      {% do return ((getstatementprefix() ~ custom_insert_sql ~ getstatementpostfix()) ~ (getstatementprefix() ~ custom_update_sql ~ getstatementpostfix())) %}
    {% endif %}
  {% elif "update_insert" == write_mode %}
    {% if custom_update_sql is none or custom_insert_sql is none %}
      {% do exceptions.raise_compiler_error("custom insert or update statement is missing for write mode " ~ write_mode) %}
    {% endif %}
    {% do return ((getstatementprefix() ~ custom_update_sql ~ getstatementpostfix()) ~ (getstatementprefix() ~ custom_insert_sql ~ getstatementpostfix())) %}
  {% endif %}
{% endmacro %}

{% macro get_update_table_action_sql( custom_table_action_dict, write_mode, table_action_sql ) %}
  {{ log("**** update table_action_sql =" ~ table_action_sql) }}
  {% if write_mode in ['update', 'update_statement_table_action'] %}
      {{ table_action_sql }}
      {%-   if custom_table_action_dict.update({'tbl_action': True}) %}{%- endif %}
  {% endif %}
{% endmacro %}

{%- macro get_exec_immediate_sql(table_action_sql, write_mode_sql) -%}
  {{ return(
        adapter.dispatch('get_exec_immediate_sql')(table_action_sql, write_mode_sql) ) }}
{%- endmacro -%}

-- The default-function is a dummy function. Since, 
-- this syntax is needed for DB2 only, the required
-- functionality is defined in "ibmdb2_utils.sql". 

{%- macro default__get_exec_immediate_sql(table_action_sql, write_mode_sql) -%}
  {{ return ("") }}
{% endmacro %}

{%- macro get_build_sql(custom_table_action_dict, table_action, write_mode, table_action_sql, write_mode_sql, target_relation) -%}
  {{ return(
        adapter.dispatch('get_build_sql')(custom_table_action_dict, table_action, write_mode, table_action_sql, write_mode_sql, target_relation) ) }}
{%- endmacro -%}

{% macro default__get_build_sql(custom_table_action_dict, table_action, write_mode, table_action_sql, write_mode_sql, target_relation ) %}
  {{ log("**** write_mode=" ~ write_mode) }}
  {{ log("**** custom_table_action_dict=" ~ custom_table_action_dict['tbl_action']) }}
  {% if custom_table_action_dict['tbl_action'] == False  %}
    {% if write_mode in ['insert','merge','update_statement_table_action'] or ("delete_insert" == write_mode and table_action in ['append','replace']) or (write_mode in ['update'] and table_action in ['replace']) or (write_mode in ['delete','insert_update','update_insert','custom_statement'] and table_action in ['create','replace']) or (write_mode in ['delete_insert'] and table_action in ['create']) %}
      {%- if table_action_sql|trim -%}
        {{ table_action_sql }}
      {%- endif -%}
    {% endif %}
  {% endif %}

  {{ write_mode_sql }}
{% endmacro %}

{% macro get_dest_relation(table_action, write_mode, custom_create_sql, custom_statement_sql, custom_update_sql, custom_insert_sql, custom_delete_sql, target_relation, temp_relation ) %}
  {% if custom_create_sql is not none or custom_statement_sql is not none or custom_update_sql is not none or custom_insert_sql is not none or custom_delete_sql is not none or custom_drop_sql is not none or "insert" != write_mode or table_action in ['append','create','truncate'] %}
    {% do return(target_relation) %}
  {% else %}
    {% do return(temp_relation) %}
  {% endif %}
{% endmacro %}

{% macro get_custom_drop_sql(table_action, write_mode, custom_drop_sql) %}
  {% if custom_drop_sql is not none and "replace" == table_action and write_mode in ['insert', 'custom_statement'] %}
    {{ custom_drop_sql | replace('\\"','"') }};
  {% endif %}
{% endmacro %}

{% materialization datastage %}

{%- set existing_relation = load_cached_relation(this) -%}
{%- set target_relation = this.incorporate(type='table') %}
{%- set temp_relation =  make_intermediate_relation(target_relation,"__dbt_tmp_" ~ invocation_id[:6]) -%}
{{ log("**** source relation" ~ source_relation)}}
{{ log("**** Validating table action") }}
{% set table_action = validate_table_action(config) %}
{% set custom_create_sql = config.get('custom_create_sql') %}

{% if existing_relation is none %}
  {% if "truncate" == table_action %}
    {% do exceptions.raise_compiler_error("target relation '" ~ target_relation ~ "' doesn't exist, nothing to truncate") %}
  {% endif %}
{% else %}
  {% if "create" == table_action and custom_create_sql is none %}
    {% do exceptions.raise_compiler_error("target relation '" ~ target_relation ~ "' already exists, cannot create it") %}
  {% endif %}
{% endif %}

{% set write_mode = validate_write_mode(config) %}
{% set custom_truncate_sql = config.get('custom_truncate_sql') %}
{% set custom_drop_sql = config.get('custom_drop_sql') %}
{% set custom_statement_sql = config.get('custom_statement_sql') %}
{% set custom_update_sql = config.get('custom_update_sql') %}
{% set custom_insert_sql = config.get('custom_insert_sql') %}
{% set custom_delete_sql = config.get('custom_delete_sql') %}
{% set use_merge = config.get('use_merge') %}
{% set force_commit = config.get('force_commit') %}
{% set use_adapter_drop_statement = config.get('use_adapter_drop_statement') %}
{% set dest_relation = get_dest_relation(table_action, write_mode, custom_create_sql, custom_statement_sql, custom_update_sql, custom_insert_sql, custom_delete_sql, target_relation, temp_relation ) %}
{% set direct_target = dest_relation == target_relation %}
{{ log("**** direct_target: " ~ direct_target ~ ", dest:" ~ dest_relation ~ ", target: " ~ target_relation) }}
{% set tgt_relation_dict = { 'tgt_relation': False} %}
{% set custom_table_action_dict = { 'tbl_action': False} %}
{%- set custom_drop_sql = get_custom_drop_sql(table_action, write_mode, custom_drop_sql) -%}
{%- set table_action_sql = get_table_action_sql(tgt_relation_dict, table_action, write_mode, custom_create_sql, custom_drop_sql, custom_truncate_sql, dest_relation, direct_target, existing_relation, use_adapter_drop_statement) -%}
{{ log("**** table action sql: " ~ table_action_sql)}}

-- debug
{#% do exceptions.raise_compiler_error("stopping here for debugging") %#}

{% set unique_key = config.get('key_columns') %}
{#--% set dest_columns = adapter.get_columns_in_relation(existing_relation) % #}
{#--% set dest_columns = adapter.get_columns_in_relation(temp_relation) %#}
{% set dest_columns = get_columns_in_query(sql) %}
{{ log("**** temp relation: " ~ temp_relation ~ ", dest_columns: " ~ dest_columns) }}

{#--%- set dest_columns_csv = get_quoted_csv(dest_columns | map(attribute="name")) -%--#}
{%- set dest_columns_csv = get_quoted_csv(dest_columns) -%}
{%- set write_mode_sql = get_write_mode_sql(write_mode, use_merge, target_relation, temp_relation, unique_key, dest_columns, custom_statement_sql, custom_update_sql, custom_insert_sql, custom_delete_sql) -%}
{{ log("**** write mode sql = " ~ write_mode_sql) }}

{%- set upd_tbl_create_action_sql = none -%}
{%- if "update_statement" != write_mode -%}
  {% if custom_create_sql is not none or custom_statement_sql is not none or custom_update_sql is not none or custom_insert_sql is not none or custom_delete_sql is not none or ("insert" != write_mode and table_action in ['append','create','truncate']) %}
    {%- if table_action_sql|trim -%}
      {%- set upd_tbl_create_action_sql = get_update_table_action_sql(custom_table_action_dict,  write_mode, table_action_sql ) -%}
      {{ log("*** upd_tbl_create_action_sql = " ~ upd_tbl_create_action_sql) }}
    {% endif %}
  {% endif %}
{%- endif %}

{%- set build_sql = getprefix() ~ get_build_sql(custom_table_action_dict, table_action, write_mode, table_action_sql, write_mode_sql, target_relation) ~ getpostfix() -%}
{{ log("**** build sql = " ~ build_sql )}}


{{ run_hooks(pre_hooks, inside_transaction=False) }}

-- `BEGIN` happens here:
{{ run_hooks(pre_hooks, inside_transaction=True) }}
{% do run_query( get_create_table_as_sql(False, temp_relation, sql) ) %}

{% if upd_tbl_create_action_sql is not none and upd_tbl_create_action_sql|trim %}
  {{ log("**** Creating Table for upd_tbl_create_action_sql ****") }}
 {% if tgt_relation_dict['tgt_relation'] == True  %}
    {% do adapter.drop_relation(dest_relation) %}
    {%-   if tgt_relation_dict.update({'tgt_relation': False}) %}{%- endif %}
 {% endif %}
  {% do run_query(getprefix() ~ upd_tbl_create_action_sql ~ getpostfix()) %}
{% endif %}

{% set temp_columns = get_columns_in_relation(temp_relation) %}
{{ log("**** temp_columns:" ~ temp_columns)}}
-- build model
{% call statement('main') -%}
 {{ log("**** drop tgt_relation ***" ~  tgt_relation_dict['tgt_relation']) }}
 {% if tgt_relation_dict['tgt_relation'] == True  %}
    {% do adapter.drop_relation(dest_relation) %}
    {%-   if tgt_relation_dict.update({'tgt_relation': False}) %}{%- endif %}
 {% endif %}
 
 {% if force_commit == "true" %}
  {{ log("****  Executing build_sql as different transactions") }}
    {%- if "replace" == table_action-%}
      {% do adapter.drop_relation(dest_relation) %}
      {% do run_query(custom_drop_sql) %}
    {% endif %}
    {%- if table_action_sql|trim -%}
      {% do run_query(table_action_sql) %}
    {% endif %}
    {% do run_query("commit;") %}
    {% do run_query(write_mode_sql) %}
{% else %}
  {{ log("****  Executing build_sql as one transaction") }}
   {{ build_sql }}
 {% endif %}
 
{%- endcall %}

{% set result = load_result('main') %}
{{ log("**** result:"~result, info=True)}}

{{ run_hooks(post_hooks, inside_transaction=True) }}

{% do persist_docs(target_relation, model) %}

-- `COMMIT` happens here
{{ adapter.commit() }}

-- finally, drop the existing/backup relation after the commit
{{ drop_relation_if_exists(temp_relation) }}

{{ run_hooks(post_hooks, inside_transaction=False) }}

{{ return({'relations': [target_relation]}) }}

{% endmaterialization %}

{% macro oracle__get_quotes(col) %}
  {{ return ('"'~col~'"') }}
{% endmacro %}

{%- macro oracle__getprefix() -%}
  {{ return ("BEGIN") }}
{%- endmacro -%}

{%- macro oracle__getpostfix() -%}
  {{ return ("END;") }}
{%- endmacro -%}

{%- macro oracle__getstatementprefix() -%}
  {{ return ("EXECUTE IMMEDIATE '") }}
{%- endmacro -%}

{%- macro oracle__getstatementpostfix() -%}
  {{ return ("';\n") }}
{%- endmacro -%}

 
{%- macro oracle__get_predicate_true() -%}
  {{ return ("1=1") }}
{%- endmacro -%}
 
{%- macro oracle__get_predicate_false() -%}
  {{ return ("1=0") }}
{%- endmacro -%}

{% macro oracle__with_cascade() %}
  {{ return ("CASCADE CONSTRAINTS") }}
{% endmacro %}

{% macro oracle__dropexception() %}
  {{ return (
" 
    EXCEPTION
         WHEN OTHERS THEN
                IF SQLCODE != -942 THEN
                     RAISE;
                END IF;
")
}}
{% endmacro %}

{%- macro oracle__if_exists() -%}
  {{ return ("") }}
{%- endmacro -%}

{%- macro oracle__quotehandling( sql ) -%}
  {{ return ( sql|replace("\'","''") ) }}
{%- endmacro -%}

{%- macro oracle__get_predicate_source(source) -%}
  {{ return (source) }}
{%- endmacro -%}

{%- macro oracle__get_predicate_dest(target) -%}
  {{ return (target) }}
{%- endmacro -%}

{%- macro oracle__get_table_alias_source() -%}
  {{ return ("") }}
{%- endmacro -%}

{%- macro oracle__get_table_alias_dest() -%}
  {{ return ("") }}
{%- endmacro -%}

{%- macro oracle__get_ending_semicolon() -%}
  {{ return ("") }}
{%- endmacro -%}

{% macro oracle__get_update_sql(use_merge, target, source, unique_key, dest_columns, predicates=none) -%}
  {%- set predicates = get_predicates(unique_key, source, target, get_predicate_false(), predicates) -%}
  {%- set update_columns =  dest_colums | map(attribute="quoted") | list -%}

  {{ sql_header if sql_header is not none }}
  {% set assign=[]%}
  {%for col in dest_columns %}
    {%- do assign.append(get_quotes(col))-%}
  {%- endfor %}
  {%- set assign_res=assign | join(', ') -%}
  {%- set dest_columns_csv = get_quoted_csv(dest_columns) -%}

  {% if use_merge %}
  merge into {{ target }} as DBT_INTERNAL_DEST using
  (select {{ dest_columns_csv }} from {{ source }}) DBT_INTERNAL_SOURCE
  on {{ predicates | join(' and ') }}
  when matched then update set {{ assign_res }}
  {% else %}
  update {{ target }}
  set
  ({{ assign_res }})
  = ( select {{ dest_columns_csv }}
    from {{ source }}
    where {{ predicates | join(' and ') }})
  {% endif %}

{% endmacro %}


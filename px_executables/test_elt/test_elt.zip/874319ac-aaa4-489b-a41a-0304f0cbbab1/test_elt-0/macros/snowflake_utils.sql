{%- macro snowflake__get_ending_semicolon() -%}
  {{ return ("") }}
{%- endmacro -%}

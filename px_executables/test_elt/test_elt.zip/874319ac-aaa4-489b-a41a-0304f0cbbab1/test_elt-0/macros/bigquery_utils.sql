{% macro bigquery__with_cascade() %}
  {{ return ('') }}
{% endmacro %}

{%- macro bigquery__getstatementpostfix() -%}
  {{ return (";\n") }}
{%- endmacro -%}

{%- macro bigquery__get_ending_semicolon() -%}
  {{ return ("") }}
{%- endmacro -%}

{% macro bigquery__get_quotes(col) %}
  {{ return ('`'~col~'`') }}
{% endmacro %}

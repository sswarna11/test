{% macro normalize_column_attr(attr) %}
{% if attr == Undefined or attr == 0 %}
{{ return(None)}}
{% else %}
{{ return(attr)}}
{% endif %}
{% endmacro %}

{% macro compare_attr(left, right) %}
{% set left_norm = normalize_column_attr(left) %}
{% set right_norm = normalize_column_attr(right) %}
{{ return (left_norm == right_norm )}}
{% endmacro%}

{% macro default__compare_schemas(left_columns, right_columns) -%}
{% set result = [] %}
{% set left_names = left_columns | map(attribute = 'column') | list %}
{% set right_names = right_columns | map(attribute = 'column') | list %}

{% for lc in left_columns %}
    {% set rc = right_columns | selectattr("column", "equalto", lc.column) | list | first %}
    {% if rc %}
      {% if lc.dtype != rc.dtype %}
        {{ result.append({ 'type':'diff_dtype', 'column': rc.column, 'left_dtype': lc.dtype, 'right_dtype': rc.dtype }) }}
      {% else %}
        {% if not compare_attr(lc.char_size,rc.char_size) or not compare_attr(lc.numeric_precision,rc.numeric_precision) or not compare_attr(lc.numeric_scale,rc.numeric_scale) %}
            {{ result.append({'type':'diff_dim', 'column': rc.column, 'dtype': lc.dtype, 'left_char_size': normalize_column_attr(lc.char_size), 'left_numeric_precision': normalize_column_attr(lc.numeric_precision), 'left_numeric_scale': normalize_column_attr(lc.numeric_scale), 'right_char_size': normalize_column_attr(rc.char_size), 'right_numeric_precision': normalize_column_attr(rc.numeric_precision), 'right_numeric_scale': normalize_column_attr(rc.numeric_scale) })}}
        {% endif %}
      {% endif %}
    {% else %} -- no target column found
        {{ result.append({'type':'no_rcol', 'column': lc.column, 'dtype': lc.dtype }) }}
    {% endif %}
{% endfor %}
{% for rc in right_columns %}
    {% if rc.column  not in left_names %}
        {{ result.append({'type':'no_lcol', 'column': rc.column, 'dtype': rc.dtype })}}
    {% endif %}
{% endfor %}

  {{ return(result) }}
{% endmacro %}

{% macro log_schema_diff(comparison_result, left_alias, right_alias) %}
{% for diff in comparison_result %}
    {% if "diff_dtype" == diff.type %}
    {{ exceptions.warn("different column types: " ~ left_alias ~" has column " ~ diff.column ~ " with data_type: " ~ diff.left_dtype ~ ", while " ~ right_alias ~ " has data_type " ~ diff.right_dtype) }}
    {% elif "diff_dim" == diff.type %}
    {{ exceptions.warn("different dimensions for column " ~ diff.column ~ " " ~ left_alias ~ " has char_size=" ~ diff.left_char_size ~ ", numeric_precision=" ~ diff.left_numeric_precision ~ ", numeric_scale=" ~ diff.left_numeric_scale ~ ", while " ~ right_alias ~ " has char_size=" ~ diff.right_char_size ~ ", numeric_precision=" ~ diff.right_numeric_precision ~ ", numeric_scale=" ~ diff.right_numeric_scale)}}
    {% elif "no_rcol" == diff.type %}
    {{ exceptions.warn(right_alias ~ " has missing column: " ~ diff.column ~ ", data_type: " ~ diff.dtype) }}
    {% elif "no_lcol" %}
    {{ exceptions.warn(left_alias ~ " has missing column: " ~ diff.column ~ ", data_type: " ~ diff.dtype) }}
    {% endif %}
{% endfor %}
{% endmacro %}
